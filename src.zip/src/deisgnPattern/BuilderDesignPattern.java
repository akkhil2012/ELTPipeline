package deisgnPattern;

public class BuilderDesignPattern {

    public static void main(String[] args){
        Retriever retriever = new Retriever.RetrieverBuilder()
                .withWorkFlow("Testing")
                .build();

        System.out.println(" with builder" + retriever.toString());


        retriever = new Retriever.RetrieverBuilder().build();


        System.out.println(" withOut builder" + retriever.toString());


    }
}



class Retriever{
    @Override
    public String toString() {
        return "Retriever{" +
                "assetName='" + assetName + '\'' +
                ", withWorkFlow='" + withWorkFlow + '\'' +
                '}';
    }

    private String assetName;

    private String withWorkFlow;

    public Retriever(RetrieverBuilder builder){
        this.withWorkFlow = builder.withWorkFlow;
    }

    public static class RetrieverBuilder{

        private String assetName;

        private String withWorkFlow;

        @Override
        public String toString() {
            return "RetrieverBuilder{" +
                    "assetName='" + assetName + '\'' +
                    ", withWorkFlow='" + withWorkFlow + '\'' +
                    '}';
        }

        public RetrieverBuilder  withWorkFlow(String workFlow){
            this.withWorkFlow=workFlow;
            return this;
        }

        public Retriever build(){
             return  new Retriever(this);
        }

    }
}


class Asset{

    private String assetName;
}

