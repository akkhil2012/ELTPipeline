package deisgnPattern;

public class DecoratorDesignPattern {

    public static void main(String args[]){

        DataAsset dataAsset = new DataAsset("Akkhil");
        dataAsset.addFeature();

        new Decorator(dataAsset).addFeature();


    }

}


interface DecoratorInter{
    void addCustomProperties(String args);
}

class Decorator implements  IAssetInterface,DecoratorInter{

    private IAssetInterface asset;

    public Decorator(IAssetInterface asset) {
        this.asset = asset;
    }

    @Override
    public void addFeature() {
        this.asset.addFeature();
        addCustomProperties("teasting");
    }


    @Override
    public void addCustomProperties(String val) {
        System.out.println("Added custom properties...... "+ val);
    }
}


interface IAssetInterface{

    void addFeature();
}

class DataAsset implements  IAssetInterface{

    private String assetName;

    public DataAsset(String assetName) {
        this.assetName = assetName;
    }

    @Override
    public void addFeature() {
        System.out.println(" Default features added.....");
    }
}
