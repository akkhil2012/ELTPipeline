package deisgnPattern;

public class SingletonPatternExample {
    public static void main(String rsg[]) {


        for (int i = 0; i < 100; i++) {
            new Thread(() -> {
                System.out.println(" Thread "+ Configuration.getInstance());
            }).start();
        }

    }
}


class Configuration {

    private static Configuration INTSANCE = new Configuration();

    private Configuration() {
        System.out.println(" Load...");
    }

    public static Configuration getInstance() {
        if (null == INTSANCE) {
            INTSANCE = new Configuration();
        }
        return INTSANCE;
    }
}
