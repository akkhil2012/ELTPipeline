package deisgnPattern;

public class FactoryMethodPattern {

    public static void main(String[] args) {

        //  IAsset asset = new BIAsset();
        AssetFactory factory = new AssetFactory();
        IAsset asset = factory.fetchAsset("biAsset");
        asset.fetchAsset();


        factory = new AssetFactory();
        asset = factory.fetchAsset("emd");
        asset.fetchAsset();
    }


}


interface IAsset {
    void fetchAsset();
}


class AssetFactory {


    public IAsset fetchAsset(String type) {
        if (type.equals(AssetType.BI.getAsstype())) {
            return new BIAsset();
        }
        return new EmdAsset();
    }
}


enum AssetType {
    EMD("emd"), BI("biAsset");

    private String asstype;

    AssetType(String type){
        this.asstype = type;
    }

    public String getAsstype() {
        return asstype;
    }
}


class BIAsset implements IAsset {

    @Override
    public void fetchAsset() {
        System.out.println(" from BI Asset");
    }
}


class EmdAsset implements IAsset {

    @Override
    public void fetchAsset() {
        System.out.println(" from EMD Asset");
    }
}
