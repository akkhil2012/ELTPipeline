package deisgnPattern;

import java.util.ArrayList;
import java.util.List;

public class ObserverDesignPatternExample {

    public static void main(String args[]){
        AssetStatus assetStatus = new AssetStatus();

        new GlossaryService(assetStatus);
        new CAMSService(assetStatus);

        assetStatus.setAssetStatus(AssetState.DRAFT);

        System.out.println("First change: draft " );

        assetStatus.setAssetStatus(AssetState.PUBLISHED);

        System.out.println("Second change" );
    }

}


class AssetStatus {
    private List<Observer> observerLsit = new ArrayList<>();

    private AssetState assetState;

    public AssetState getAssetStatus() {
        return assetState;
    }

    public void setAssetStatus(AssetState assetState) {
        this.assetState = assetState;
        notifyAllStackHolders();
    }

    private void notifyAllStackHolders(){
        observerLsit.forEach(ob -> ob.notifyEndUsers());
    }
}

enum AssetState{
    DRAFT, PUBLISHED
}


abstract class Observer {
    protected AssetStatus assetStatus;

    public abstract void notifyEndUsers();
}


class GlossaryService extends Observer {
    public GlossaryService(AssetStatus assetStatus) {
        this.assetStatus = assetStatus;
    }

    @Override
    public void notifyEndUsers() {
         System.out.println(" State changed is ---1---> " + assetStatus.getAssetStatus());
    }
}


class CAMSService extends Observer {

    public CAMSService(AssetStatus assetStatus) {
        this.assetStatus = assetStatus;
    }

    @Override
    public void notifyEndUsers() {
        System.out.println(" State changed is ---2---> " + assetStatus.getAssetStatus());
    }
}


