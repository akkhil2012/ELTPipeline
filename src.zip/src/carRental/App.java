package carRental;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

// https://leetcode.com/discuss/interview-question/object-oriented-design/1144881/flipkart-machine-coding-round-design-car-rental-system
/*
Requirement -

This rental system will have some stations where car will be parked.
Every station will have some type of cars (example - SUV, Hatchback, Bike, Sedan etc)
and will have some fixed price for each type of car ($11/hour for SUV, 12$/per hour for Sedan etc.)
User can book car from any station and drop at same or any other station
When user searches for a car - list all stations with that type of available car + station with cheapest price should
be on top followed by second cheapest and so on..(order by increasing per hour price)
When two stations have same price, list station nearest to the customer
Supported operations

Onboard station - (station_name, List
Search Vehicle
Book vehicle
Drop vehicle
Station Report - available car of each type, booked car of each type etc.

 */
public class App {


    public static void main(String args[]){

        RentalSystem rentalSystem = new RentalSystem();
        List<Station> ans = rentalSystem.searchVehicle(VehicleType.SUV);
        ans.stream().forEach(val -> System.out.println(" "+ val.getStationName()));
    }
}



class RentalSystem{

    private List<Station> stationList;

    private Map<Station,List<Vehicle>> stationToVehicleMapper;

    public RentalSystem(){
        // initialize stations
        init();
    }


    private void init(){
        // inititalize station
         stationList = List.of(new Station("1"),new Station("2"),new Station("3"),new Station("4"));

        // initialize vehicles per station
        stationList.forEach(station -> station.init(station.getStationName()));
    }


    // search Cab
    List<Station> searchVehicle(VehicleType vehicleType){

        List<List<Vehicle>> vehicleList = new ArrayList<>();
        List<Station> stationWithVehicleList = new ArrayList<>();

        for(Station station : stationList){
            List<Vehicle> vehicleLst =
                    station.getVehicleList().stream()
                            .filter(val -> val.getVehicleType().equals(vehicleType))
                            .collect(Collectors.toList());
            if(vehicleLst!=null) {
                stationWithVehicleList.add(station);
                vehicleList.add(vehicleLst);
            }

        }

        List<Vehicle> flattenedList = vehicleList.stream()
                .flatMap(List::stream)
                .collect(Collectors.toList());


        stationWithVehicleList.stream()
                .forEach(station -> station.getVehicleToPriceMapper().entrySet()
                        .stream()
                        .filter(entry -> entry.getKey().equals(vehicleType))
                        .sorted((s1, s2) -> s1.getKey().compareTo(s1.getKey()))
                        .collect(Collectors.toList()));


       System.out.println(" Station sorted.....");
        return stationWithVehicleList;
        //return stationWithVehicleList.sort((a,b) -> a.getVehicleToPriceMapper());

       // List s = stationList.stream().forEach(station -> station.getVehicleList().stream()
         //               .collect(Collectors.toList()));

                //.stream().filter(vehicle -> vehicle.getVehicleType().equals(vehicleType)).collect(Collectors.toList());



    }

    // book vehicle

    // station report
}


class Station{

    private String stationName;

    public Map<VehicleType, Long> getVehicleToPriceMapper() {
        return vehicleToPriceMapper;
    }

    private List<Vehicle> vehicleList;
    private Map<VehicleType,Long> vehicleToPriceMapper = new HashMap<>();

    public List<Vehicle> getVehicleList() {
        return vehicleList;
    }

    public String getStationName() {
        return stationName;
    }

    public Station(String name){
        stationName = name;
        init(name);
    }

    void init(String name){
        // inititalize Vehicle
        vehicleList = List.of(new Vehicle(String.valueOf(Math.random()),VehicleType.SUV),
                new Vehicle(String.valueOf(Math.random()),VehicleType.SUV),
                new Vehicle(String.valueOf(Math.random()),VehicleType.SEDAN));

        vehicleToPriceMapper.put(VehicleType.SUV,100l);
        vehicleToPriceMapper.put(VehicleType.SEDAN,70l);
        // initialize vehicles price mapper
    }

}

class Vehicle{

    private String vehicleNumber;
    private VehicleType vehicleType;

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public Vehicle(String vehicleNumber, VehicleType vehicleType) {
        this.vehicleNumber = vehicleNumber;
        this.vehicleType = vehicleType;
    }
}


enum VehicleType{
     SUV,SEDAN
}

enum VehicleStatus{
    BOOKED,AVAILABLE
}



class User{
    private String name;

}

class Ride{

    private Station stationFrom;

    public Ride(Station stationFrom, Station stationTo) {
        this.stationFrom = stationFrom;
        this.stationTo = stationTo;
    }

    private Station stationTo;
}











