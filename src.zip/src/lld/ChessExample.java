package lld;


//https://lldcoding.com/design-lld-chess-machine-coding-interview

/*
  two players
  Chess
  Rules
  Black white
  turns
  Roll
  history of moves
  end at checkmate , draw
 */


import java.util.HashMap;
import java.util.Map;

class Chess{

    static{
        Map<Integer,Block> blockMapper = new HashMap<>();
    }
    private ChessBlock[][] grid;

    private  final int SIZE = 8;

    private boolean isFirstPlayer = false;

    public Chess(){
        initilaizeBoard();
    }


    public void assignPalyers(){
        Player playerOne = new Player(BlockType.WHITE);
        Player playerTwo = new Player(BlockType.BLACK);
    }

    public void startGame(){

    }

    private void initilaizeBoard(){
        boolean flag = true;
        for(int i=0;i<8;i++) {  // BLACK
            for (int j = 0; j < 8; j++) {
                ChessBlock blockToInitilaize = grid[i][j];
                if(flag) {
                    blockToInitilaize.setBlockType(BlockType.BLACK);
                }else{
                    blockToInitilaize.setBlockType(BlockType.WHITE);
                }
                flag = !flag;
            }
        }



        for(int i=0;i<2;i++){  // BLACK
            for(int j=0;j<8;j++){
                ChessBlock blockToInitilaize = grid[i][j];
                Block block = new Block();
                block.setBlockType(BlockType.BLACK);
                blockToInitilaize.setChessBlockState(ChessBlockState.OCCUPIED);
            }
        }



        for(int i=6;i<7;i++){
            for(int j=0;j<8;j++){
                ChessBlock blockToInitilaize = grid[i][j];
                Block block = new Block();
                block.setBlockType(BlockType.WHITE);
                blockToInitilaize.setChessBlockState(ChessBlockState.OCCUPIED);
            }
        }

    }

}

class ChessBlock{

  private BlockName blockName;
  private BlockType blockType;

    public void setBlockType(BlockType blockType) {
        this.blockType = blockType;
    }

    private ChessBlockState chessBlockState;

    public void setChessBlockState(ChessBlockState chessBlockState) {
        this.chessBlockState = chessBlockState;
    }

    public ChessBlock(BlockType blockType) {
        this.blockType = blockType;
  }
}

class Player{

    private BlockType blockType;

    public Player(BlockType blockType) {
        this.blockType = blockType;
    }
}


class Block{
    private BlockType blockType;
    private BlockName blockName;

    public void setBlockType(BlockType blockType) {
        this.blockType = blockType;
    }






}

enum BlockName{
    PAWN,ROOK, BISHOP,KNIGHT,KING,QUEEN

}

enum BlockType{
    BLACK,WHITE
}

enum ChessBlockState{
    FREE,OCCUPIED
}

public class ChessExample {


}
