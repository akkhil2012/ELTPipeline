package lld;


import java.sql.Time;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Random;
import java.util.TreeSet;

/*
https://leetcode.com/discuss/interview-question/490962/Design-Meeting-Scheduler

Design Meeting Scheduler. Here there are n given meeting rooms. Book a meeting in any meeting room at given interval(starting time, end time).
Also send notifications to all person who are invited for meeting.
You should use Calender for tracking date and time. And also history of all the meetings which are booked and meeting room.
write an API for client who will give date and time and API should return meeting room with booked scheduled time.
client should also query for history of last 20 booked meetings.
Is meeting room available? etc
 */
public class TimeScheduler {

    public static void main(String args[]){

        MeetingScheduler meetingScheduler = new MeetingScheduler(5);

        List<Attendee> attendeeList = List.of(new Attendee(),new Attendee());
        Time start = new Time(11,12,135);
        Time end = new Time(12,12,135);

        Room meetingRoom =  meetingScheduler.bookMeetingRoom(start,end,new Date(),attendeeList);

        System.out.println(" Meeting room booked : " + meetingRoom);
    }

}


class MeetingScheduler{


    private LinkedList<Room> roomList = new LinkedList<>();

    private Set<Room> bookedRooms;
    public MeetingScheduler(int rooms){
        init(rooms);
    }

    public void init(int rooms){

        for(int i=0;i<rooms;i++){
            roomList.add(new Room(i));
        }
        bookedRooms = new TreeSet<>();

    }


    public Room bookMeetingRoom(Time startTime,Time endTime,Date dateOfBooking,List<Attendee> attendeeList){
        // check if room available
        Room availableRoom = checkIfRoomAvailable(startTime,endTime,dateOfBooking);
        if(availableRoom!=null){
                Meeting meeting = new Meeting(dateOfBooking,startTime,endTime,attendeeList);
                availableRoom.setMeetingRoomStatus(MeetingRoomStatus.BOOKED);
                availableRoom.getMeetings().add(meeting);
                bookedRooms.add(availableRoom);
        }
        // send Notification
        sendNotifications(attendeeList);
        return availableRoom;
    }

    public Set<Room> fetchLastMeetings(){
        return bookedRooms;
    }


    private void sendNotifications(List<Attendee> attendeeList){
        attendeeList
                .stream()
                .forEach(
                        att -> System.out.println(" Send notification for " + att)
                );
    }

    private Room checkIfRoomAvailable(Time startTime,Time endTime,Date dateOfBooking){
        if(roomList.isEmpty())
            return  null;
        return  roomList.pop();
    }



    public List<Room> allRoomsBookedForTimeFrame(Time startTime,Time endTime,Date dateOfBooking){
        List<Room> allMeetingsSchdeuled = new ArrayList<>();

        for(Room  room : roomList){
            if(room.getMeetingRoomStatus().equals(MeetingRoomStatus.BOOKED)){
                    for(Meeting meet : room.getMeetings()){
                        if(meet.getMeetingDate().equals(dateOfBooking) &&
                          meet.getStartTime().equals(startTime)
                         && meet.getEndTime().equals(endTime)){
                            allMeetingsSchdeuled.add(room);
                        }
                }
            }
        }

    return  allMeetingsSchdeuled;
    }

    // book meeting

    // send Notifications

    // history of meetings

    //fetch meeting room for time frame



}


class Room{

    private int roomNumber;

    public MeetingRoomStatus getMeetingRoomStatus() {
        return meetingRoomStatus;
    }

    @Override
    public String toString() {
        return "Room{" +
                "roomNumber=" + roomNumber +
                ", meetingRoomStatus=" + meetingRoomStatus +
                ", meetings=" + meetings +
                '}';
    }

    public List<Meeting> getMeetings() {
        return meetings;
    }

    public void setMeetings(List<Meeting> meetings) {
        this.meetings = meetings;
    }

    public Room(int roomNumber, MeetingRoomStatus meetingRoomStatus, List<Meeting> meetings) {
        this.roomNumber = roomNumber;
        this.meetingRoomStatus = MeetingRoomStatus.AVAILABLE;
        this.meetings = new LinkedList<>();
    }

    private MeetingRoomStatus meetingRoomStatus;

    public void setMeetingRoomStatus(MeetingRoomStatus meetingRoomStatus) {
        this.meetingRoomStatus = meetingRoomStatus;
    }


    public Room(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    private List<Meeting> meetings;
}

class Meeting{

    private Date meetingDate;
    private Time startTime,endTime;

    public Date getMeetingDate() {
        return meetingDate;
    }

    @Override
    public String toString() {
        return "Meeting{" +
                "meetingDate=" + meetingDate +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", attendeeList=" + attendeeList +
                '}';
    }

    public Time getStartTime() {
        return startTime;
    }

    public Time getEndTime() {
        return endTime;
    }

    public List<Attendee> getAttendeeList() {
        return attendeeList;
    }

    private List<Attendee> attendeeList;

    public Meeting(Date meetingDate, Time startTime, Time endTime, List<Attendee> attendeeList) {
        this.meetingDate = meetingDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.attendeeList = attendeeList;
    }
}

enum MeetingRoomStatus{
    AVAILABLE,BOOKED
}


class Attendee{

}
