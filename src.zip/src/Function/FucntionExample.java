package Function;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FucntionExample {

    public static void main(String args[]){

        Function<Integer,Integer> squareFunction = data -> data*data;

        Function<Integer,String> stringFunction = data -> String.valueOf(data+" : "+data);

        int result = squareFunction.apply(11);

        System.out.println(": " + result);

        squareFunction.andThen(stringFunction).apply(200);


        List<Integer> lst = List.of(1,2,3);

        List<Integer> res = lst.stream()
                        .map(squareFunction)
                                .collect(Collectors.toList());

        System.out.print("<-------------->");
        res.forEach(System.out::println);

        lst.forEach(ans -> System.out.print("===> "+ ans));


        List<String> stringRes =
        lst.stream()
               .map(squareFunction.andThen(stringFunction))
               .collect(Collectors.toList());

        stringRes.forEach(System.out::println);


        lst.forEach(FucntionExample::testFunction);
        //squareFunction.compose(stringFunction).apply(11);

    }

    private static void testFunction(Integer integer) {
        System.out.println(" Inside test Function........");
    }




}
