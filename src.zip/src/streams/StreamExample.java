package streams;

import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public class StreamExample {

    public static void main(String args[]){

        List<Integer> lst = List.of(2,3,4,5,11,33,55,77,13,13,33,33);

        //lst.stream().allMatch(val -> val.equals(13)))
       // System.out.println(" All match "+ lst.stream().allMatch(val -> val.equals(13)));
       // System.out.println(" Any match "+ lst.stream().anyMatch(val -> val.equals(13)));

        List<Integer> listOfInteger =
                (List<Integer>) lst.stream().filter(val -> ((int)val%2==0)).collect(Collectors.toList());

        //listOfInteger.stream().forEach(System.out::println);

        // flatMap to list
        List<Integer> listOfIntegerFlatMap =
                (List<Integer>) lst.stream().flatMap(map -> Stream.of(2)).collect(Collectors.toList());

        listOfIntegerFlatMap.stream().forEach(System.out::println);

        /*(List<Double>) lst.stream().flatMapToDouble(newVal -> DoubleStream.of(Double.parseDouble((String) newVal)))
                .forEach(res -> System.out::println);*/

        Map<Integer,Integer> mapper = Map.of(1,11,2,22,3,33);

        /*mapper.entrySet()
                .stream()
                .collect(Collectors.groupingBy(Map.Entry::getKey, Collectors.counting()))
                .forEach((key,value) -> System.out.println("key "+ key + " : value " + value));
*/

        Map<Integer,List<Integer>> mapperForlist = Map.of(1,List.of(11,111),2,List.of(22,222),3,List.of(33,333));

        mapperForlist.entrySet()
                .stream()
                .collect(Collectors.groupingBy(Map.Entry::getKey, Collectors.counting()))
                .forEach((key,value) -> System.out.println("key "+ key + " : value " + value));

        Map<Integer, Long> occurances =
                lst.stream()
                        .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
        occurances.forEach((element,count) -> System.out.println(" Element "+ element +": count " + count));


        lst.stream().sorted().forEach(System.out::println);

        lst.stream().skip(3).forEach(System.out::print );


        System.out.println(lst.stream().reduce((a,b) -> a+b));

        //int[] resArray = lst.stream().toArray();


    }



}

