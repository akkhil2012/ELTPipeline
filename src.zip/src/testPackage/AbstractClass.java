package testPackage;

public abstract class AbstractClass {

    AbstractClass(){

    }

    public void test(){
        System.out.println("inside abstract class....."+ this.getClass());
    }

}
