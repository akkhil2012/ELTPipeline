package testPackage;

public interface TestInterface {

}
