package testPackage;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

public class MultiThreadingExample {

    //Task task = new Task();

    public static void main(String args[]) {

        /*
          using blocking operation
         */
        for (int i = 0; i < 10; i++) {
            Task task = new Task(Thread.currentThread().getName());
            task.run();
        }


    }

    static class Task implements Runnable {


        private String i;

        public Task(String i) {
            this.i = i;
        }

        public void writeToFileSyncronously(String i) throws IOException {
            System.out.println(" Thread  " + Thread.currentThread().getName() + "  writing......");
            File file = new File("/tmp/8dec/testSample" + i + ".txt");
            file.createNewFile();
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write("File written by thread " + Thread.currentThread().getName());

            System.out.println("Write to file successful.");
        }

        @Override
        public void run() {
            try {
                writeToFileSyncronously(i);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}

