package testPackage;

public class ImmutableClassExample {
}
